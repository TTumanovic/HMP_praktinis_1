import { StyleSheet, Text, View, FlatList, Pressable } from 'react-native';
import React, { useState } from 'react';

export default function App() {
  const [kreps, setKreps] = useState(0);

  const Items = [
    {
      id: 1,
      name: "Batai",
      price: 50,
      category: "Avalyne"
    },
    {
      id: 2,
      name: "Akiniai",
      price: 15,
      category: "Aksesuarai"
    },
    {
      id: 3,
      name: "Black Hoodie",
      price: 75,
      category: "Dzemperiai"
    }
  ];

  function ProductCard({ name, price, category, addKreps }) {
    return (
      <View style={styles.card}>
        <Text style={styles.cardText}>{name}</Text>
        <Text style={styles.cardText}>Kaina: {price}$</Text>
        <Text style={styles.cardText}>Kategorija: {category}</Text>

        <Pressable
          style={({ pressed }) => [
            styles.addButton,
            pressed && styles.buttonPressed
          ]}
          onPress={addKreps}
        >
          <Text style={styles.buttonText}>Prideti i krepseli</Text>
        </Pressable>
      </View>
    );
  }

  function  CartInfo({ count }) {
    return (
      <View style={styles.kreps}>
        <Text style={styles.krepsText}>
          Krepselyje prekiu: {count}
        </Text>
      </View>
    );
  }

  const Prideti = () => {
    setKreps(kreps + 1);
  };

  const Isvalyti = () => {
    setKreps(0);
  };

  return (
    <View style={styles.container}>
      <CartInfo count={kreps} />

      <FlatList
        data={Items}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <ProductCard
            name={item.name}
            price={item.price}
            category={item.category}
            addKreps={Prideti}
          />
        )}
      />

      <Pressable
        style={({ pressed }) => [
          styles.clearButton,
          pressed && styles.buttonPressed
        ]}
        onPress={Isvalyti}
      >
        <Text style={styles.buttonText}>Isvalyti krepseli</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 8,
  },

  kreps: {
    alignItems: 'center',
    backgroundColor: '#569C51',
    padding: 10,
    borderRadius: 8,
    marginBottom: 15
  },

  krepsText: {
    fontSize: 23,
    fontWeight: '500',
    color:'white'
  },

  card: {
    alignItems: 'left',
    flex: 1,
    padding: 20,
    borderWidth: 3,
    borderRadius: 8,
    marginBottom: 10
  },

  addButton: {
    backgroundColor: '#2196F3',
    padding: 12,
    borderRadius: 20,
    alignItems: 'center',
    marginTop: 10,
    backgroundColor:'#2FB021'
  },

  clearButton: {
    backgroundColor: '#F44336',
    padding: 12,
    borderRadius: 20,
    alignItems: 'center',
    marginTop: 10
  },

  buttonText: {
    color: 'white',
    fontSize: 15,
    fontWeight: 'bold'
  },

  buttonPressed: {
    opacity: 0.6
  },
  cardText:{
    fontSize:20,
    fontWeight:500
  }
});